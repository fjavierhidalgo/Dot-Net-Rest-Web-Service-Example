create database bd_DotNetEx
go

use bd_DotNetEx
go

create table users(
id int identity(1000,1) primary key,
name varchar(50) not null,
birthdate date not null
)
go

insert into users(name,birthdate) values ('Alexander Garcia','12/05/1970')
insert into users(name,birthdate) values ('Gonzalo Diego','08/10/1995')
insert into users(name,birthdate) values ('Marta Fernandez','24/01/1992')
insert into users(name,birthdate) values ('Luis Antunez','21/05/1982')
insert into users(name,birthdate) values ('Anna Maria Smith','14/09/1978')
