﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;
using Autofac.Integration.WebApi;
using DNExMasterCRUD.App_Start;

namespace DNExMasterCRUD
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration Config)
        {
            // Configuración y servicios de API web

            //Autofac definition
            Config.DependencyResolver = new AutofacWebApiDependencyResolver(DependencyContainer.BuildContainer(Config));

            //Cors definition
            var permittedUrl = new EnableCorsAttribute("*", "*", "*");
            Config.EnableCors(permittedUrl);

            // Rutas de API web
            Config.MapHttpAttributeRoutes();

            Config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            Config.Routes.MapHttpRoute(
            name: "Error404",
            routeTemplate: "api/{*url}",
            defaults: new { controller = "NotFound", action = "ErrorNotFound" }
         );
        }
    }
}
