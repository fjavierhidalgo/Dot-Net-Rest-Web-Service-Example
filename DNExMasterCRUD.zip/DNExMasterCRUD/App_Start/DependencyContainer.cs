﻿using DNExMasterCRUD.Controllers;
using Autofac;
using Autofac.Integration.WebApi;
using System.Net;
using System.Reflection;
using System.Web.Http;

namespace DNExMasterCRUD.App_Start
{
    public class DependencyContainer
    {
        public static IContainer BuildContainer(HttpConfiguration Configuration)
        {
#if DEBUG
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
#endif

            var builder = new ContainerBuilder();

            builder.RegisterApiControllers(typeof(NotFoundController).GetTypeInfo().Assembly);
            builder.RegisterApiControllers(typeof(UserController).GetTypeInfo().Assembly);
            builder.RegisterWebApiFilterProvider(Configuration);

            // Register all services.

            var container = builder.Build();
            return container;
        }
    }
}