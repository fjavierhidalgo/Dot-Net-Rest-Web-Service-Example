﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using DNExMasterCRUD.Data.Models;


namespace DNExMasterCRUD.Controllers
{
    public class UserController : BaseController 
    {
        static bd_DotNetExUserEntities db = new bd_DotNetExUserEntities();

      
        /// <summary>
        /// The list of all users
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IEnumerable<users>> Get()
        {

            using (var _db = new bd_DotNetExUserEntities())
            {
                //LINQ to entity
                List<users> _users = await
                (from u in _db.users orderby u.id select u).ToListAsync();

                return _users;
            }

       
        }

        /// <summary>
        /// The data of user with id indicated after last slash
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<users> Get( int Id )
        {
            using (var _db = new bd_DotNetExUserEntities())
            {
                
                users _user=await _db.users.FindAsync(Id);
                return _user;
            }

        }

        /// <summary>
        /// Update the data of user with id indicated after last slash
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        public async Task<IHttpActionResult> Put(int Id, users User)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (Id != User.id)
            {
                return BadRequest();
            }
            
            using (var _db = new bd_DotNetExUserEntities())
            {
                _db.Entry(User).State = EntityState.Modified;
                try
                {
                    await _db.SaveChangesAsync();
                }
                catch (Exception)
                {
                    if (!(_db.users.Count(e => e.id == Id) > 0)) { return NotFound(); }
                    else { throw; }
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Add a new user to users entity
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post(users User)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var _db = new bd_DotNetExUserEntities())
            {
                _db.users.Add(User);
                await _db.SaveChangesAsync();

                return CreatedAtRoute("DefaultApi", new { id = User.id }, User);
            }
        }

        /// <summary>
        /// Delete of user with id indicated after last slash
        /// </summary>
        /// <returns></returns>
        [HttpDelete]
        public async Task<IHttpActionResult> Delete(int Id)
        {
            using (var _db = new bd_DotNetExUserEntities())
            {
                users _user = await _db.users.FindAsync(Id);
                if (_user == null)
                {
                    return NotFound();
                }

                _db.users.Remove(_user);
                await _db.SaveChangesAsync();

                return Ok(_user);
            }
        }

        

    }
}
