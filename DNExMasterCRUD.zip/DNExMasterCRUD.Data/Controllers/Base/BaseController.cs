﻿using System.Web.Http;

namespace DNExMasterCRUD.Controllers
{
    public class BaseController : ApiController
    {
    }
}